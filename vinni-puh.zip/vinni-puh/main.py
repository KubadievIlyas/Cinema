from PyQt6 import QtCore, QtGui, QtWidgets
from vizual import Ui_Dialog
import sqlite3
import pandas as pd
import traceback


class MyDialog(QtWidgets.QDialog):
    def __init__(self):
        super().__init__()
        self.ui = Ui_Dialog()
        self.ui.setupUi(self)
        self.load_data()
        self.ui.pushButton_2.clicked.connect(self.show_output_table)
        self.ui.pushButton_5.clicked.connect(self.show_input_table)
        self.ui.pushButton.clicked.connect(self.add_record)
        self.ui.pushButton_3.clicked.connect(self.delete_record)
        self.ui.pushButton_4.clicked.connect(self.export_to_excel)
        self.ui.AboutProgram.clicked.connect(self.about_program)

    def load_data(self):
        conn = sqlite3.connect('database/cinema.db')
        query = "SELECT * FROM movies"
        result = conn.execute(query)

        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(["id", "Время", "Фильм", "Зал", "Продано"])

        for row_num, row_data in enumerate(result):
            for col_num, data in enumerate(row_data):
                item = QtGui.QStandardItem(str(data))
                model.setItem(row_num, col_num, item)

        self.ui.tableView.setModel(model)

        conn.close()

    def show_output_table(self):
        conn = sqlite3.connect('database/cinema.db')
        query = '''SELECT output.name, SUM(movies.sold)
                   FROM movies
                   JOIN output ON movies.movie = output.id_name
                   GROUP BY movies.movie'''
        result = conn.execute(query)

        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(["Название зала", "Общая сумма проданных билетов"])

        for row_num, row_data in enumerate(result):
            hall_name, sold_tickets = row_data
            item_hall = QtGui.QStandardItem(str(hall_name))
            item_sold = QtGui.QStandardItem(str(sold_tickets))
            model.setItem(row_num, 0, item_hall)
            model.setItem(row_num, 1, item_sold)

        self.ui.tableView.setModel(model)

        conn.close()

    def show_input_table(self):
        conn = sqlite3.connect('database/cinema.db')
        query = "SELECT * FROM movies"
        result = conn.execute(query)

        model = QtGui.QStandardItemModel()
        model.setHorizontalHeaderLabels(["id", "Время", "Фильм", "Зал", "Продано"])

        for row_num, row_data in enumerate(result):
            for col_num, data in enumerate(row_data):
                item = QtGui.QStandardItem(str(data))
                model.setItem(row_num, col_num, item)

        self.ui.tableView.setModel(model)

        conn.close()

    def add_record(self):
        dialog = QtWidgets.QDialog()
        layout = QtWidgets.QVBoxLayout()

        id_label = QtWidgets.QLabel("ID:")
        self.id_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(id_label)
        layout.addWidget(self.id_line_edit)

        time_label = QtWidgets.QLabel("Время:")
        self.time_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(time_label)
        layout.addWidget(self.time_line_edit)

        hall_label = QtWidgets.QLabel("Фильм:")
        self.hall_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(hall_label)
        layout.addWidget(self.hall_line_edit)

        movie_label = QtWidgets.QLabel("Зал:")
        self.movie_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(movie_label)
        layout.addWidget(self.movie_line_edit)

        sold_label = QtWidgets.QLabel("Продано:")
        self.sold_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(sold_label)
        layout.addWidget(self.sold_line_edit)

        ok_button = QtWidgets.QPushButton("OK")
        ok_button.clicked.connect(self.save_record)
        layout.addWidget(ok_button)

        dialog.setLayout(layout)
        dialog.setWindowTitle("Добавить запись")
        dialog.exec()

    def save_record(self):
        id_val = self.id_line_edit.text()
        time_val = self.time_line_edit.text()
        hall_val = self.hall_line_edit.text()
        movie_val = self.movie_line_edit.text()
        sold_val = self.sold_line_edit.text()

        conn = sqlite3.connect('database/cinema.db')
        query = "INSERT INTO movies (id, time, movie, hall, sold) VALUES (?, ?, ?, ?, ?)"
        conn.execute(query, (id_val, time_val, movie_val, hall_val , sold_val))
        conn.commit()
        conn.close()

        self.load_data()

    def delete_record(self):
        dialog = QtWidgets.QDialog()
        layout = QtWidgets.QVBoxLayout()

        id_label = QtWidgets.QLabel("ID записи для удаления:")
        self.id_delete_line_edit = QtWidgets.QLineEdit()
        layout.addWidget(id_label)
        layout.addWidget(self.id_delete_line_edit)

        ok_button = QtWidgets.QPushButton("Удалить")
        ok_button.clicked.connect(self.confirm_delete_record)
        layout.addWidget(ok_button)

        dialog.setLayout(layout)
        dialog.setWindowTitle("Удалить запись")
        dialog.exec()

    def confirm_delete_record(self):
        id_val = self.id_delete_line_edit.text()

        conn = sqlite3.connect('database/cinema.db')
        query = "DELETE FROM movies WHERE id = ?"
        conn.execute(query, (id_val,))
        conn.commit()
        conn.close()

        self.load_data()

    def export_to_excel(self):
        try:
            conn = sqlite3.connect('database/cinema.db')
            query = '''SELECT output.name, SUM(movies.sold)
                       FROM movies
                       JOIN output ON movies.movie = output.id_name
                       GROUP BY movies.movie'''
            result = conn.execute(query)

            data = []
            for row_data in result:
                data.append(row_data)

            df = pd.DataFrame(data, columns=["Название зала", "Общая сумма проданных билетов"])
            file_path, _ = QtWidgets.QFileDialog.getSaveFileName(self, 'Save File', "", "Excel Files (*.xlsx)")

            if file_path:
                df.to_excel(file_path, index=False)

            conn.close()

        except Exception as e:
            traceback.print_exc()
            QtWidgets.QMessageBox.critical(self, "Error", f"An error occurred: {str(e)}")


    def about_program(self):
        dialog = QtWidgets.QDialog()
        layout = QtWidgets.QVBoxLayout()
        dialog.setWindowTitle("О программе")
        id_label = QtWidgets.QLabel("Выполнено студентами КМПО РАНХиГС группы 32ИС-21 \nКубадиевым Ильясом и Головачевой Полиной \n11.04.2024 ")
        layout.addWidget(id_label)
        dialog.setLayout(layout)
        dialog.exec()

if __name__ == "__main__":
    import sys

    app = QtWidgets.QApplication(sys.argv)
    dialog = MyDialog()
    dialog.show()
    sys.exit(app.exec())
