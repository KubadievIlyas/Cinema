import sqlite3

def insert_data_into_output():
    data = [
        (1, "Большой"),
        (2, "Средний"),
        (3, "Малый")
    ]

    conn = sqlite3.connect('cinema.db')
    c = conn.cursor()

    c.executemany('''INSERT INTO output (id_name, name) 
                     VALUES (?, ?)''', data)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    insert_data_into_output()
