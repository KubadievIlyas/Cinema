import sqlite3

def create_database():
    conn = sqlite3.connect('cinema.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS movies
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 time TEXT NOT NULL,
                 hall INTEGER NOT NULL,
                 movie TEXT NOT NULL,
                 sold INTEGER NOT NULL)''')
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_database()
