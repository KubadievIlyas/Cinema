import sqlite3

def insert_data():
    data = [
        ("12-00", 1, "Чапаев", 20),
        ("13-00", 2, "Захват", 50),
        ("14-00", 1,  "Любовь_и_голуби", 10)
    ]

    conn = sqlite3.connect('cinema.db')
    c = conn.cursor()

    c.executemany('''INSERT INTO movies (time, hall, movie, sold) 
                     VALUES (?, ?, ?, ?)''', data)

    conn.commit()
    conn.close()

if __name__ == "__main__":
    insert_data()
