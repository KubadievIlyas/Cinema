import sqlite3

def create_output_table():
    conn = sqlite3.connect('cinema.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS output
                 (id INTEGER PRIMARY KEY AUTOINCREMENT,
                 id_name INTEGER NOT NULL,
                 name TEXT NOT NULL)''')
    conn.commit()
    conn.close()

if __name__ == "__main__":
    create_output_table()
